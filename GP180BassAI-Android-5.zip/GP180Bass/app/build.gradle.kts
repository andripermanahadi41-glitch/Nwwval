plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.gp180.bassai"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.gp180.bassai"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.11.0")
}

// Unduh Tailwind & Lucide ke assets/lib supaya app jalan offline.
// Berjalan otomatis sebelum build (Android Studio maupun GitHub Actions).
// Jika unduhan gagal, index.html tetap memakai CDN saat runtime.
val downloadWebLibs by tasks.registering {
    val libDir = layout.projectDirectory.dir("src/main/assets/lib").asFile
    val targets = mapOf(
        "tailwind.js" to "https://cdn.tailwindcss.com/3.4.17",
        "lucide.min.js" to "https://cdn.jsdelivr.net/npm/lucide@0.263.1/dist/umd/lucide.min.js"
    )
    outputs.upToDateWhen { false }
    doLast {
        libDir.mkdirs()
        targets.forEach { (name, url) ->
            val f = File(libDir, name)
            if (f.exists() && f.length() > 1000) return@forEach
            try {
                java.net.URL(url).openStream().use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                logger.lifecycle("Terunduh: $name (${f.length()} byte)")
            } catch (e: Exception) {
                f.delete()
                logger.warn("Gagal unduh $name: ${e.message}. App akan memakai CDN saat runtime.")
            }
        }
    }
}
tasks.named("preBuild") { dependsOn(downloadWebLibs) }
