package com.gp180.bassai

import android.content.Context
import android.content.Intent
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiInputPort
import android.media.midi.MidiManager
import android.media.midi.MidiOutputPort
import android.media.midi.MidiReceiver
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

/** Jembatan JS -> USB MIDI native Android. Hanya Program Change & Control Change (MIDI standar). */
class MidiBridge(private val context: Context, private val web: WebView) {
    private val midi = context.getSystemService(Context.MIDI_SERVICE) as? MidiManager
    private val main = Handler(Looper.getMainLooper())
    private var device: MidiDevice? = null
    private var port: MidiInputPort? = null
    private var outPort: MidiOutputPort? = null
    private val sx = ByteArrayOutputStream()
    private var inSx = false

    /** Menerima data dari pedal; merakit pesan SysEx utuh lalu kirim ke JS sebagai hex. */
    private val receiver = object : MidiReceiver() {
        override fun onSend(msg: ByteArray, offset: Int, count: Int, timestamp: Long) {
            for (i in offset until offset + count) {
                val v = msg[i].toInt() and 0xFF
                if (v >= 0xF8) continue
                if (v == 0xF0) { sx.reset(); inSx = true }
                else if (inSx && v >= 0x80 && v != 0xF7) { inSx = false }
                if (inSx) {
                    sx.write(v)
                    if (v == 0xF7) {
                        inSx = false
                        val hex = sx.toByteArray().joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }
                        main.post { web.evaluateJavascript("onMidiRx('$hex')", null) }
                    }
                }
            }
        }
    }

    private fun usable(): List<MidiDeviceInfo> =
        midi?.devices?.filter { it.inputPortCount > 0 } ?: emptyList()

    private fun status(msg: String, ok: Boolean) {
        main.post { web.evaluateJavascript("onMidiStatus(${JSONObject.quote(msg)},$ok)", null) }
    }

    @JavascriptInterface
    fun listDevices(): String {
        val arr = JSONArray()
        usable().forEach {
            arr.put(it.properties.getString(MidiDeviceInfo.PROPERTY_NAME) ?: "MIDI Device")
        }
        return arr.toString()
    }

    @JavascriptInterface
    fun connect(index: Int) {
        val m = midi
        val info = usable().getOrNull(index)
        if (m == null || info == null) {
            status("Perangkat MIDI tidak ditemukan", false)
            return
        }
        disconnect()
        m.openDevice(info, MidiManager.OnDeviceOpenedListener { dev ->
            if (dev == null) {
                status("Gagal membuka perangkat (izin ditolak?)", false)
            } else {
                device = dev
                port = dev.openInputPort(0)
                if (dev.info.outputPortCount > 0) {
                    outPort = dev.openOutputPort(0)
                    outPort?.connect(receiver)
                }
                if (port != null) status("Terhubung", true) else status("Port MIDI tidak tersedia", false)
            }
        }, main)
    }

    @JavascriptInterface
    fun disconnect() {
        try { outPort?.disconnect(receiver) } catch (e: Exception) {}
        try { outPort?.close() } catch (e: Exception) {}
        outPort = null
        try { port?.close() } catch (e: Exception) {}
        try { device?.close() } catch (e: Exception) {}
        port = null
        device = null
    }

    @JavascriptInterface
    fun programChange(channel: Int, program: Int): Boolean {
        val p = port ?: return false
        val b = byteArrayOf((0xC0 or (channel and 0x0F)).toByte(), (program and 0x7F).toByte())
        return try { p.send(b, 0, b.size); true } catch (e: Exception) { false }
    }

    @JavascriptInterface
    fun controlChange(channel: Int, cc: Int, value: Int): Boolean {
        val p = port ?: return false
        val b = byteArrayOf(
            (0xB0 or (channel and 0x0F)).toByte(),
            (cc and 0x7F).toByte(),
            (value and 0x7F).toByte()
        )
        return try { p.send(b, 0, b.size); true } catch (e: Exception) { false }
    }

    /** Kirim SysEx mentah. Hanya menerima F0 ... F7 dengan byte data 00-7F. */
    @JavascriptInterface
    fun sendSysEx(hex: String): Boolean {
        val p = port ?: return false
        val bytes = try {
            hex.trim().split(Regex("[\\s,]+")).filter { it.isNotEmpty() }.map { it.toInt(16) }
        } catch (e: Exception) { return false }
        if (bytes.size < 2 || bytes.first() != 0xF0 || bytes.last() != 0xF7) return false
        if (bytes.subList(1, bytes.size - 1).any { it !in 0..0x7F }) return false
        val b = ByteArray(bytes.size) { bytes[it].toByte() }
        return try { p.send(b, 0, b.size); true } catch (e: Exception) { false }
    }

    @JavascriptInterface
    fun share(text: String) {
        main.post {
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
            }
            context.startActivity(Intent.createChooser(i, null))
        }
    }
}
